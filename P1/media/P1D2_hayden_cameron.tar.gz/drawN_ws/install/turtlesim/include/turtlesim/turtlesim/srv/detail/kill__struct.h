// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from turtlesim:srv/Kill.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "turtlesim/srv/kill.h"


#ifndef TURTLESIM__SRV__DETAIL__KILL__STRUCT_H_
#define TURTLESIM__SRV__DETAIL__KILL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/Kill in the package turtlesim.
typedef struct turtlesim__srv__Kill_Request
{
  rosidl_runtime_c__String name;
} turtlesim__srv__Kill_Request;

// Struct for a sequence of turtlesim__srv__Kill_Request.
typedef struct turtlesim__srv__Kill_Request__Sequence
{
  turtlesim__srv__Kill_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} turtlesim__srv__Kill_Request__Sequence;

// Constants defined in the message

/// Struct defined in srv/Kill in the package turtlesim.
typedef struct turtlesim__srv__Kill_Response
{
  uint8_t structure_needs_at_least_one_member;
} turtlesim__srv__Kill_Response;

// Struct for a sequence of turtlesim__srv__Kill_Response.
typedef struct turtlesim__srv__Kill_Response__Sequence
{
  turtlesim__srv__Kill_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} turtlesim__srv__Kill_Response__Sequence;

// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "service_msgs/msg/detail/service_event_info__struct.h"

// constants for array fields with an upper bound
// request
enum
{
  turtlesim__srv__Kill_Event__request__MAX_SIZE = 1
};
// response
enum
{
  turtlesim__srv__Kill_Event__response__MAX_SIZE = 1
};

/// Struct defined in srv/Kill in the package turtlesim.
typedef struct turtlesim__srv__Kill_Event
{
  service_msgs__msg__ServiceEventInfo info;
  turtlesim__srv__Kill_Request__Sequence request;
  turtlesim__srv__Kill_Response__Sequence response;
} turtlesim__srv__Kill_Event;

// Struct for a sequence of turtlesim__srv__Kill_Event.
typedef struct turtlesim__srv__Kill_Event__Sequence
{
  turtlesim__srv__Kill_Event * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} turtlesim__srv__Kill_Event__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TURTLESIM__SRV__DETAIL__KILL__STRUCT_H_
