// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TURTLESIM__MSG__POSE_HPP_
#define TURTLESIM__MSG__POSE_HPP_

#include "turtlesim/msg/detail/pose__struct.hpp"
#include "turtlesim/msg/detail/pose__builder.hpp"
#include "turtlesim/msg/detail/pose__traits.hpp"
#include "turtlesim/msg/detail/pose__type_support.hpp"

#endif  // TURTLESIM__MSG__POSE_HPP_
